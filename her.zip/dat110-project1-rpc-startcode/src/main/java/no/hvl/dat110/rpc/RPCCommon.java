package no.hvl.dat110.rpc;

public class RPCCommon {

	// RPCID for default stop method on the RPC server
	// no other RPC methods should use this 0 as RPC id
	public static byte RPIDSTOP = 0;
}
